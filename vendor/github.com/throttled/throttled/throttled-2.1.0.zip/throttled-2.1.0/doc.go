// Package throttled implements rate limiting access to resources such
// as HTTP endpoints.
package throttled // import "github.com/throttled/throttled"
