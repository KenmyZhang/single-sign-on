// Package storetest provides a helper for testing throttled stores.
package storetest // import "github.com/throttled/throttled/store/storetest"
